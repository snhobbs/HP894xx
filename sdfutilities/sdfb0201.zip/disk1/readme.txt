 ==============================================================================
	     Hewlett-Packard Standard Data Format (SDF) Utilities
 ==============================================================================


 Revision B.02.01 - 11/17/94


 Installation:

	Install these utilities by copying them onto your hard disk into a
	directory that's in your PATH statement or create a directory and add
	the new directory to to your PATH statement in your AUTOEXEC.BAT.


 Defect Reports:

	The file DEFECT.TXT contains a defect report template that should be
	used when reporting defects to Hewlett-Packard.  Defects can be
	submitted via electronic mail (Internet), FAX, US mail or your HP
	Field/Systems Engineer.


 Changes to User's Guide:

	On page B-11, add the following to the allowable values of measType:

	    11 = swept FFT measurement
	    12 = analog demodulation measurement
	    13 = digital demodulation measurement
